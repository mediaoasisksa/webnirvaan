export const knowledgeBase = `
WebNirvaan Services:
- Web development
- AI integrations
- Ecommerce
- SEO optimization

Case Studies:
- Jynak AI: AI platform
- Janagate: Business website
- Consl2: Corporate consulting
`;
